<br>
<p class="mi-subtitulo text-center">Agregar País</p>
<div class="container" style="height: 350px">
	<form id="formulario-agrega-pais"  method="POST" accept-charset="utf-8">
		<div class="row">	
			<div class=" col-md-offset-2 col-md-1">
				<div class="form-group text-right">
				 <p>País:</p>		 
				</div>
		  	</div>
			<div class="col-md-2">
				<div class="form-group">
				  <input id="pais-nuevo" name="pais-nuevo" class="form-control input-sm text-center" type="text" autocomplete="off" required="required">				 
				</div>
		  	</div>
		</div>
		<div class="row">
			<div class="col-md-offset-3 col-md-1">
				<input type="submit" id="btn-agrega-pais" class="btn btn-default remodal-confirm" value="Ingresar">
			</div>
	    	
	    </div>
    </form>
</div>

    
