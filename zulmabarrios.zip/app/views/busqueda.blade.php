<div class="container padding-bottom-40">
	<div class="row">
		<div class="col-md-offset-1">
			<ul>
			    <li><a href="{{ URL::to('/provincias/show/7') }}" title="">Ventas</a></li>
			    <li><a href="" title="">Alquileres</a></li>
			    <li></li>
			    <li></li>
			</ul>
		</div>
	</div>
	<br>
	<div class="row">
		<div class="col-md-offset-1">
			<ul>
			    <li><a href="{{ URL::to('/provincias/show/7') }}" title="">Casas</a></li>
			    <li><a href="" title="">Departamentos</a></li>
			    <li></li>
			    <li></li>
			</ul>
		</div>
	</div>
</div>
