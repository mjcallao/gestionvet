<?php

class Descripcion extends \Eloquent {
	protected $table = 'descripciones';
	protected $fillable = [];
}