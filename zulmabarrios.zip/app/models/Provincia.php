<?php

class Provincia extends \Eloquent {
	protected $table = 'provincias';
	protected $fillable = [];
}