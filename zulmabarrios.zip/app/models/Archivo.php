<?php

class Archivo extends \Eloquent {
	protected $table = 'imagenes';
	protected $fillable = [];
}