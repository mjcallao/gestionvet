<?php

class Partido extends \Eloquent {
	protected $table = 'partidos';
	protected $fillable = [];
}