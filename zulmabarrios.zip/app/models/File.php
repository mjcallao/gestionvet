<?php

class File extends \Eloquent {
	protected $fillable = [];
}