<?php

class Visita extends \Eloquent {

	protected $table = 'visitas';
	protected $fillable = [];
}