<?php

class Localidad extends \Eloquent {
	protected $table = 'localidades';
	protected $fillable = [];
}