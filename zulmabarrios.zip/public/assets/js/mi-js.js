$(document).on('ready', function() 
{
	


});